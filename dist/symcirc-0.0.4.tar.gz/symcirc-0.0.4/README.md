# SymCirc

A python library for symbolic circuit analysis.

## What can it do?

* 
* Something

## Build

Build just source distribution (tar.gz)

* python setup.py sdist

or complete build (including wheel)

* python -m build

## Install
* symcirc runs on sympy so you'll need to install it first
* pip install symcirc-0.0.1.tar.gz 